#!/bin/bash
#

# 1. 输入要发布的版本号
# 2. 修改主题 _config.yml 中的 info.version
# 3. 修改主题 package.json 中的 version
# 4. 提交 commit

VERSION=$1

function start() {
  #statements
}
